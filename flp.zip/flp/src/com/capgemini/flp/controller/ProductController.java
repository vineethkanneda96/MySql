package com.capgemini.flp.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.flp.dto.AdminLogin;
import com.capgemini.flp.dto.Customer;
import com.capgemini.flp.dto.MerchantLogin;
import com.capgemini.flp.dto.MerchantProduct;
import com.capgemini.flp.dto.Cart;
import com.capgemini.flp.exception.ProductException;
import com.capgemini.flp.service.IProductService;

@Controller
public class ProductController {
	
	@Autowired
	IProductService productService;

	@RequestMapping(value={"/","/homepage"})
	public ModelAndView showHomePage(HttpServletResponse response,HttpServletRequest request) throws ServletException, IOException{
		
		ModelAndView mv=new ModelAndView("homepage");
		try {
			List<MerchantProduct> products=productService.getProducts();
			response.setContentType("image/jpeg, image/jpg, image/png, image/gif");
			
			mv.addObject("products",products);
		} catch (ProductException e) {
			e.getMessage();
		}
		return mv;
	}
	
	
	@RequestMapping("/electronics")
	public ModelAndView  electronics(){
		ModelAndView mv=new ModelAndView("electronics");
		try {
			List<MerchantProduct> products=productService.getElectronicProducts();
			mv.addObject("products",products);
		} catch (ProductException e) {
			e.getMessage();
		}
		return mv;
	}
	
	@RequestMapping("/fashion")
	public ModelAndView  fashion(){
		ModelAndView mv=new ModelAndView("fashion");
		try {
			List<MerchantProduct> products=productService.getFashionProducts();
			mv.addObject("products",products);
		} catch (ProductException e) {
			e.getMessage();
		}
		return mv;
	}
	@RequestMapping(value="/delete")
	public ModelAndView removeItemFromTheCart(@RequestParam("cartId") Integer cartId)
	{
			
		try {
			productService.removeItemFromTheCart(cartId);
		} catch (ProductException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			//System.out.println(c);
			
		return new ModelAndView("delete","message","item removed from the cart");
		
	}
	@RequestMapping("/furniture")
	public ModelAndView  furniture(){
		ModelAndView mv=new ModelAndView("furniture");
		try {
			List<MerchantProduct> products=productService.getFurnitureProducts();
			mv.addObject("products",products);
		} catch (ProductException e) {
			e.getMessage();
		}
		return mv;
	}
	
	@RequestMapping("/sportsbooksandmore")
	public ModelAndView  sportsbooksandmore(){
		ModelAndView mv=new ModelAndView("sportsbooksandmore");
		try {
			List<MerchantProduct> products=productService.getSportsBooksAndMoreProducts();
			mv.addObject("products",products);
		} catch (ProductException e) {
			e.getMessage();
		}
		return mv;
	}
	
	@RequestMapping("/productpage")
	public ModelAndView  productpage(@RequestParam(value="name")String product){
		ModelAndView mv=new ModelAndView("productpage");
		try {
			MerchantProduct products=productService.getProduct(product);
			List<MerchantProduct> prodsbyCategory=productService.getSimilarProductsByCategory(products.getProductCategory());
			mv.addObject("productbyCat",prodsbyCategory);
			mv.addObject("products",products);
		} catch (ProductException e) {
			e.getMessage();
		}
		return mv;
	}
	
	/*@RequestMapping("/SignUp")
	public ModelAndView  signUp(){
		return new ModelAndView("SignUp");
	}*/
	
	@RequestMapping("/sortedelectronics")
	public ModelAndView  sortingElectronics(@RequestParam(value="category")String category,@RequestParam(value="asc")int asc){
		ModelAndView mv=new ModelAndView("sortedelectronics");
		try {
			List<MerchantProduct> products=productService.getProductAsc(category,asc);
			mv.addObject("products",products);
		} catch (ProductException e) {
			e.getMessage();
		}
		return mv;
	}
	
	@RequestMapping("/sortedfurniture")
	public ModelAndView  sortedFurniture(@RequestParam(value="category")String category,@RequestParam(value="asc")int asc){
		ModelAndView mv=new ModelAndView("sortedfurniture");
		try {
			List<MerchantProduct> products=productService.getProductAsc(category,asc);
			mv.addObject("products",products);
		} catch (ProductException e) {
			e.getMessage();
		}
		return mv;
	}
	
	@RequestMapping("/sortedfashion")
	public ModelAndView  sortingFashion(@RequestParam(value="category")String category,@RequestParam(value="asc")int asc){
		ModelAndView mv=new ModelAndView("sortedfashion");
		try {
			List<MerchantProduct> products=productService.getProductAsc(category,asc);
			mv.addObject("products",products);
		} catch (ProductException e) {
			e.getMessage();
		}
		return mv;
	}
	
	@RequestMapping("/sortedsportsbooksandmore")
	public ModelAndView  sortingSportsbooksandmore(@RequestParam(value="category")String category,@RequestParam(value="asc")int asc){
		ModelAndView mv=new ModelAndView("sortedsportsbooksandmore");
		try {
			List<MerchantProduct> products=productService.getProductAsc(category,asc);
			mv.addObject("products",products);
		} catch (ProductException e) {
			e.getMessage();
		}
		return mv;
	}
	

	@RequestMapping("/invoice")
	public ModelAndView  orderNow(@RequestParam(value="id")int id){
		try {
			
			MerchantProduct a=productService.getProductDetails(id);
			System.out.println(a.getProductQuantity());
			if(a.getProductQuantity()>0){
				return new ModelAndView("invoice","invoice",a);
			}else{
				return new ModelAndView("orderError");
			}
			
		} catch (ProductException e) {
			e.getMessage();
		}
		return null;
	}
	
	
	@RequestMapping("/hello")
	public ModelAndView abc() {

		int productid = 354;
		int orderid = 10;

		try {
			MerchantProduct a=productService.getInvoice(productid, orderid);
			
			return new ModelAndView("index","mp",a);
		} catch (ProductException e) {

		System.out.println(e.getMessage());
		}
		return null;

	}
	@RequestMapping("/index")
	public ModelAndView index() {
		return new ModelAndView("index","mp","");
	}
	@RequestMapping(value="/addTocart")
	public ModelAndView cartDetails(@RequestParam("productId") Integer productId)
	{
		Cart c=null;
			
			String emailId= "abc@gmail.com";//session.getAttribute(customeremailId);
			
			try {
				c = (Cart) productService.addItemsToCart(productId,emailId);
			} catch (ProductException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		return new ModelAndView("updatedcart","cartDetails",c);
		
	}
	
	/*@RequestMapping(value="/Home.jsp",method=RequestMethod.GET)
	public String home(){
			return "Home";
			}*/
		
			

	@RequestMapping("/moreSimilarProducts")
	public ModelAndView showSimilarProducts(@RequestParam("productCategory")String productCategory,@RequestParam("productName")String productName)
	{
		ModelAndView mv = new ModelAndView("moreSimilarProducts");
		
	try
	{
		
		List<MerchantProduct> prodsbyCategory=productService.getSimilarProductsByCategory(productCategory);
		
		mv.addObject("productbyCat",prodsbyCategory);	
		
        List<MerchantProduct> prodsbyName=productService.getSimilarProductsByName(productName);
		
		mv.addObject("productbyName",prodsbyName);	
	}
	catch(ProductException ex)
	{
		ex.printStackTrace();
	}

	return mv;
	}
	@RequestMapping(value="/cart")
	public ModelAndView cartDetails(@RequestParam("emailId") String emailId)
	{
			
			//String emailId= "abc@gmail.com"; //session.getAttribute(customeremailId);
		List<Cart> c=null;
		try {
			c = productService.cartDetails(emailId);
		} catch (ProductException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
			
		return new ModelAndView("cartdetails","message",c);
		
	}
	
	
}
