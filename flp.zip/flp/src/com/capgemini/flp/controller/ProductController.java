package com.capgemini.flp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.flp.dto.Admin;
import com.capgemini.flp.exception.ProductException;
import com.capgemini.flp.service.IProductService;

@Controller
public class ProductController {
	
	@Autowired
	IProductService productService;

	@RequestMapping(value={"/","/homepage"})
	public ModelAndView showHomePage(){
		
		ModelAndView mv=new ModelAndView("homepage");
		try {
			List<Admin> products=productService.getProducts();
			mv.addObject("products",products);
		} catch (ProductException e) {
			e.getMessage();
		}
		return mv;
	}
	
	@RequestMapping("/category")
	public ModelAndView  category(){
		ModelAndView mv=new ModelAndView("category");
		try {
			List<Admin> products=productService.getProducts();
			mv.addObject("products",products);
		} catch (ProductException e) {
			e.getMessage();
		}
		return mv;
	}
	
	@RequestMapping(value="/products",method=RequestMethod.GET)
	public ModelAndView  products(@RequestParam(value="name")String name){
		ModelAndView mv=new ModelAndView("products");
		try {
			List<Admin> products=productService.getProductsBasedOnCategory(name);
			mv.addObject("products",products);
		} catch (ProductException e) {
			e.getMessage();
		}
		return mv;
	}
}
