package com.capgemini.flp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.flp.dto.Admin;
import com.capgemini.flp.exception.ProductException;
import com.capgemini.flp.service.IProductService;

@Controller
public class ProductController {
	
	@Autowired
	IProductService productService;

	@RequestMapping(value={"/","/homepage"})
	public ModelAndView showHomePage(){
		
		ModelAndView mv=new ModelAndView("homepage");
		try {
			List<Admin> products=productService.getProducts();
			mv.addObject("products",products);
		} catch (ProductException e) {
			e.getMessage();
		}
		return mv;
	}
	
	
	@RequestMapping("/electronics")
	public ModelAndView  electronics(){
		ModelAndView mv=new ModelAndView("electronics");
		try {
			List<Admin> products=productService.getElectronicProducts();
			mv.addObject("products",products);
		} catch (ProductException e) {
			e.getMessage();
		}
		return mv;
	}
	
	@RequestMapping("/fashion")
	public ModelAndView  fashion(){
		ModelAndView mv=new ModelAndView("fashion");
		try {
			List<Admin> products=productService.getFashionProducts();
			mv.addObject("products",products);
		} catch (ProductException e) {
			e.getMessage();
		}
		return mv;
	}
	
	@RequestMapping("/furniture")
	public ModelAndView  furniture(){
		ModelAndView mv=new ModelAndView("furniture");
		try {
			List<Admin> products=productService.getFurnitureProducts();
			mv.addObject("products",products);
		} catch (ProductException e) {
			e.getMessage();
		}
		return mv;
	}
	
	@RequestMapping("/sportsbooksandmore")
	public ModelAndView  sportsbooksandmore(){
		ModelAndView mv=new ModelAndView("sportsbooksandmore");
		try {
			List<Admin> products=productService.getSportsBooksAndMoreProducts();
			mv.addObject("products",products);
		} catch (ProductException e) {
			e.getMessage();
		}
		return mv;
	}
	
	@RequestMapping("/productpage")
	public ModelAndView  productpage(@RequestParam(value="name")String product){
		ModelAndView mv=new ModelAndView("productpage");
		try {
			Admin products=productService.getProduct(product);
			mv.addObject("products",products);
		} catch (ProductException e) {
			e.getMessage();
		}
		return mv;
	}
	
	/*@RequestMapping("/SignUp")
	public ModelAndView  signUp(){
		return new ModelAndView("SignUp");
	}*/
	
	@RequestMapping("/sortedascending")
	public ModelAndView  sortingAscending(@RequestParam(value="category")String category,@RequestParam(value="asc")boolean asc){
		ModelAndView mv=new ModelAndView("sortedascending");
		try {
			List<Admin> products=productService.getProductAsc(category,asc);
			mv.addObject("products",products);
		} catch (ProductException e) {
			e.getMessage();
		}
		return mv;
	}
	
/*	@RequestMapping("/sorteddescending")
	public ModelAndView  sortedDescending(@RequestParam(value="category")String category){
		ModelAndView mv=new ModelAndView("sorteddescending");
		try {
			List<Admin> products=productService.getProductDesc(category);
			mv.addObject("products",products);
		} catch (ProductException e) {
			e.getMessage();
		}
		return mv;
	}
	*/
	@RequestMapping("/payment")
	public ModelAndView  orderNow(@RequestParam(value="id")int id){
		ModelAndView mv=null;
		try {
			System.out.println(id);
			
			Admin a=productService.getProductDetails(id);
			System.out.println("hello");
			System.out.println(a.getProductQuantity());
			if(a.getProductQuantity()>0){
				//mv.addObject("order",a);
				return new ModelAndView("payment","order",a);
			}else{
				return new ModelAndView("orderError");
			}
			
		} catch (ProductException e) {
			e.getMessage();
		}
		return mv;
	}
	
	/*@RequestMapping("/sortedelectronics")
	public ModelAndView  sortingElectronics(@RequestParam(value="asc")boolean asc){
		ModelAndView mv=new ModelAndView("sortedascending");
		try {
			List<Admin> products=productService.getProductAsc("Electronics",asc);
			mv.addObject("products",products);
		} catch (ProductException e) {
			e.getMessage();
		}
		return mv;
	}*/
	
}
