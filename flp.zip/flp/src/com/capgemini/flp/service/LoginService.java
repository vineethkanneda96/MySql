package com.capgemini.flp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.flp.dao.ILoginDAO;
import com.capgemini.flp.dto.Cart;
import com.capgemini.flp.exception.LoginException;
import com.capgemini.flp.exception.ProductException;

@Service
public class LoginService implements ILoginService {

	@Autowired
	private ILoginDAO dao;

	public boolean findUser(String emailId,String password) throws LoginException{
		return dao.findUser(emailId,password);
	}
	@Override
	public boolean findAdmin(String emailId, String password)
			throws LoginException {
		return dao.findAdmin(emailId,password);
	}
	@Override
	public boolean findMerchant(String emailId, String password)
			throws LoginException {
		return dao.findMerchant(emailId,password);
	}
	@Override
	public List<Cart> cartDetails(String emailId) throws ProductException {
		// TODO Auto-generated method stub
		return dao.cartDetails(emailId);
	}
	@Override
	public Cart addItemsToCart(Integer productId, String emailId) throws ProductException {
		// TODO Auto-generated method stub
	return	dao.addItemsToCart(productId, emailId);
		
	}
	@Override
	public void removeItemFromTheCart(Integer cartId) throws ProductException {
		// TODO Auto-generated method stub
		dao.removeItemFromTheCart(cartId);
	}

}
