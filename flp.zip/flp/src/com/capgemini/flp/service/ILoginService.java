package com.capgemini.flp.service;

import java.util.List;

import com.capgemini.flp.dto.Cart;
import com.capgemini.flp.exception.LoginException;
import com.capgemini.flp.exception.ProductException;


public interface ILoginService {

	public boolean findUser(String emailId,String password) throws LoginException;
	public boolean findAdmin(String emailId,String password) throws LoginException;
	public boolean findMerchant(String emailId,String password) throws LoginException;
	
	public List<Cart> cartDetails(String emailId) throws ProductException;
	public Cart addItemsToCart(Integer productId, String emailId) throws ProductException;

	public void removeItemFromTheCart(Integer cartId)throws ProductException;

}
