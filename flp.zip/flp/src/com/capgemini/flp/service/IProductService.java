package com.capgemini.flp.service;

import java.util.List;

import com.capgemini.flp.dto.Admin;
import com.capgemini.flp.exception.ProductException;

public interface IProductService {
	
	public List<Admin> getProducts() throws ProductException;

	public List<Admin> getElectronicProducts() throws ProductException;
	
	public List<Admin> getFashionProducts() throws ProductException;
	
	public List<Admin> getFurnitureProducts() throws ProductException;
	
	public List<Admin> getSportsBooksAndMoreProducts() throws ProductException;

	public Admin getProduct(String product) throws ProductException ;

	public List<Admin> getProductAsc(String name,boolean asc) throws ProductException;

	public List<Admin> getProductDesc(String category) throws ProductException;

	public Admin getProductDetails(int id) throws ProductException;
}
