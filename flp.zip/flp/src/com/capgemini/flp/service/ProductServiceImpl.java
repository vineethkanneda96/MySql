package com.capgemini.flp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.flp.dao.IProductDao;
import com.capgemini.flp.dto.Admin;
import com.capgemini.flp.exception.ProductException;

@Transactional
@Service
public class ProductServiceImpl implements IProductService {
	
	@Autowired
	IProductDao products;

	@Override
	public List<Admin> getProducts() throws ProductException {
		return products.getProducts();
	}

	@Override
	public List<Admin> getElectronicProducts() throws ProductException {
		return products.getElectronicProducts();
	}

	@Override
	public List<Admin> getFashionProducts() throws ProductException {
		return products.getFashionProducts();
	}

	@Override
	public List<Admin> getFurnitureProducts() throws ProductException {
		return products.getFurnitureProducts();
	}

	@Override
	public List<Admin> getSportsBooksAndMoreProducts() throws ProductException {
		return products.getSportsBooksAndMoreProducts();
	}

	@Override
	public Admin getProduct(String product) throws ProductException {
		return products.getProduct(product);
	}

	@Override
	public List<Admin> getProductAsc(String name,boolean asc) throws ProductException {
	return products.getProductsAsc(name,asc);
	}

	@Override
	public List<Admin> getProductDesc(String category) throws ProductException {
		return products.getProductDesc(category);
	}

	@Override
	public Admin getProductDetails(int id) throws ProductException {
		return products.getProductDetails(id);
	}
	
}
