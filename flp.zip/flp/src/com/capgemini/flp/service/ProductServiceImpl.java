package com.capgemini.flp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.flp.dao.IProductDao;
import com.capgemini.flp.dto.MerchantProduct;
import com.capgemini.flp.exception.ProductException;


@Transactional
@Service
public class ProductServiceImpl implements IProductService {
	
	@Autowired
	IProductDao products;

	@Override
	public List<MerchantProduct> getProducts() throws ProductException {
		return products.getProducts();
	}

	@Override
	public List<MerchantProduct> getElectronicProducts() throws ProductException {
		return products.getElectronicProducts();
	}

	@Override
	public List<MerchantProduct> getFashionProducts() throws ProductException {
		return products.getFashionProducts();
	}

	@Override
	public List<MerchantProduct> getFurnitureProducts() throws ProductException {
		return products.getFurnitureProducts();
	}

	@Override
	public List<MerchantProduct> getSportsBooksAndMoreProducts() throws ProductException {
		return products.getSportsBooksAndMoreProducts();
	}

	@Override
	public MerchantProduct getProduct(String product) throws ProductException {
		return products.getProduct(product);
	}

	@Override
	public List<MerchantProduct> getProductAsc(String name,int asc) throws ProductException {
	return products.getProductsAsc(name,asc);
	}

	@Override
	public List<MerchantProduct> getProductDesc(String category) throws ProductException {
		return products.getProductDesc(category);
	}

	@Override
	public MerchantProduct getProductDetails(int id) throws ProductException {
		return products.getProductDetails(id);
	}

	@Override
	public MerchantProduct getInvoice(int productid, int orderid)
			throws ProductException {
		return products.getInvoice(productid, orderid);
	}

	@Override
	public List<MerchantProduct> getBestSelling(String category) throws ProductException {
		return products.getProductDesc(category);
	}

	@Override
	public List<MerchantProduct> getSimilarProductsByCategory(String productCategory)
			throws ProductException {
		
		return products.getSimilarProductsByCategory(productCategory);
		}
	
	
	
	public List<MerchantProduct> getSimilarProductsByName(String productName) throws ProductException {
		return products.getSimilarProductsByName(productName);
	}
	
	
}
