package com.capgemini.flp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.flp.dao.IProductDao;
import com.capgemini.flp.dto.Admin;
import com.capgemini.flp.exception.ProductException;

@Transactional
@Service
public class ProductServiceImpl implements IProductService {
	
	@Autowired
	IProductDao products;

	@Override
	public List<Admin> getProducts() throws ProductException {
		return products.getProducts();
	}

	@Override
	public List<Admin> getProductsBasedOnCategory(String name) throws ProductException {
		
		return products.getProductsBasedOnCategory(name);
	}

}
