package com.capgemini.flp.dao;

import java.util.List;

import com.capgemini.flp.dto.MerchantProduct;
import com.capgemini.flp.exception.ProductException;


public interface IProductDao {
	
	public List<MerchantProduct> getProducts() throws ProductException;

	public List<MerchantProduct> getElectronicProducts() throws ProductException;
	
	public List<MerchantProduct> getFashionProducts() throws ProductException;
	
	public List<MerchantProduct> getFurnitureProducts() throws ProductException;
	
	public List<MerchantProduct> getSportsBooksAndMoreProducts() throws ProductException;
	
	public MerchantProduct getProduct(String product) throws ProductException ;

	public List<MerchantProduct> getProductsAsc(String name,int asc) throws ProductException;

	public List<MerchantProduct> getProductDesc(String category) throws ProductException;

	public MerchantProduct getProductDetails(int id) throws ProductException;
	
	public MerchantProduct getInvoice(int productid, int orderid)throws ProductException;

	public List<MerchantProduct> getBestSelling(String category)throws ProductException;

	public List<MerchantProduct> getSimilarProductsByCategory(String productCategory) throws ProductException;

	public List<MerchantProduct> getSimilarProductsByName(String productName)throws ProductException;

	
}
