package com.capgemini.flp.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.flp.dto.Admin;
import com.capgemini.flp.exception.ProductException;

@Repository
public class ProductDaoImpl implements IProductDao {

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public List<Admin> getProducts() throws ProductException {
		try{
			TypedQuery<Admin> query=entityManager.createQuery("from Admin",Admin.class);
			return query.getResultList();
			}catch(Exception e){
				throw new ProductException(e.getMessage());
			}
	}

	@Override
	public List<Admin> getElectronicProducts() throws ProductException {
		try{
			TypedQuery<Admin> query=entityManager.createQuery("select admin from Admin admin where admin.productCategory='Electronics'",Admin.class);
			return query.getResultList();
			}catch(Exception e){
				throw new ProductException(e.getMessage());
			}
	}

	@Override
	public List<Admin> getFashionProducts() throws ProductException {
		try{
			TypedQuery<Admin> query=entityManager.createQuery("select admin from Admin admin where admin.productCategory='Fashion' or admin.productCategory='fashion' ",Admin.class);
			return query.getResultList();
			}catch(Exception e){
				throw new ProductException(e.getMessage());
			}
	}

	@Override
	public List<Admin> getFurnitureProducts() throws ProductException {
		try{
			TypedQuery<Admin> query=entityManager.createQuery("select admin from Admin admin where admin.productCategory='Furniture' or admin.productCategory='furniture' ",Admin.class);
			return query.getResultList();
			}catch(Exception e){
				throw new ProductException(e.getMessage());
			}
	}

	@Override
	public List<Admin> getSportsBooksAndMoreProducts() throws ProductException {
		try{
			TypedQuery<Admin> query=entityManager.createQuery("select admin from Admin admin where admin.productCategory='sports' or admin.productCategory='books' or admin.productCategory='more' ",Admin.class);
			System.out.println("jdhygfi");
			return query.getResultList();
			}catch(Exception e){
				throw new ProductException(e.getMessage());
			}
	}

	@Override
	public Admin getProduct(String product) throws ProductException {
		try{
			TypedQuery<Admin> query=entityManager.createQuery("select admin from Admin admin where admin.productName='"+product+"'",Admin.class);
			return query.getSingleResult();
			}catch(Exception e){
				throw new ProductException(e.getMessage());
			}
	}

	@Override
	public List<Admin> getProductsAsc(String name) throws ProductException {
	
		try{
			TypedQuery<Admin> query=entityManager.createQuery("select admin from Admin admin where admin.productCategory='"+name+"' order by admin.productPrice ASC",Admin.class);
			return query.getResultList();
			}catch(Exception e){
				throw new ProductException(e.getMessage());
			}
	}

	@Override
	public List<Admin> getProductDesc(String category) throws ProductException {
          
		try{
			TypedQuery<Admin> query=entityManager.createQuery("select admin from Admin admin where admin.productCategory='"+category+"' order by admin.productPrice DESC",Admin.class);
			return query.getResultList();
			}catch(Exception e){
				throw new ProductException(e.getMessage());
			}
	}

	@Override
	public Admin getProductDetails(int id) throws ProductException {
		try{
			TypedQuery<Admin> query=entityManager.createQuery("select admin.productQuantity from Admin admin where admin.productId='"+id+"' ",Admin.class);
			System.out.println("hi");
			return query.getSingleResult();
			}catch(Exception e){
				throw new ProductException(e.getMessage());
			}
	}
	
}
