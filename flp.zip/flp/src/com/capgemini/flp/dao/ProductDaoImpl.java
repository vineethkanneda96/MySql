package com.capgemini.flp.dao;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Stream;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.flp.dto.Admin;
import com.capgemini.flp.dto.MerchantProduct;
import com.capgemini.flp.dto.MerchantProduct;
import com.capgemini.flp.exception.ProductException;
import com.capgemini.flp.service.ProductServiceImpl;

@Repository
public class ProductDaoImpl implements IProductDao {

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public List<Admin> getProducts() throws ProductException {
		try{
			TypedQuery<Admin> query=entityManager.createQuery("from Admin",Admin.class);
			return query.getResultList();
			}catch(Exception e){
				throw new ProductException(e.getMessage());
			}
	}

	@Override
	public List<Admin> getElectronicProducts() throws ProductException {
		try{
			TypedQuery<Admin> query=entityManager.createQuery("select admin from Admin admin where admin.productCategory='Electronics'",Admin.class);
			return query.getResultList();
			}catch(Exception e){
				throw new ProductException(e.getMessage());
			}
	}

	@Override
	public List<Admin> getFashionProducts() throws ProductException {
		try{
			TypedQuery<Admin> query=entityManager.createQuery("select admin from Admin admin where admin.productCategory='Fashion' or admin.productCategory='fashion' ",Admin.class);
			return query.getResultList();
			}catch(Exception e){
				throw new ProductException(e.getMessage());
			}
	}

	@Override
	public List<Admin> getFurnitureProducts() throws ProductException {
		try{
			TypedQuery<Admin> query=entityManager.createQuery("select admin from Admin admin where admin.productCategory='Furniture' or admin.productCategory='furniture' ",Admin.class);
			return query.getResultList();
			}catch(Exception e){
				throw new ProductException(e.getMessage());
			}
	}

	@Override
	public List<Admin> getSportsBooksAndMoreProducts() throws ProductException {
		try{
			TypedQuery<Admin> query=entityManager.createQuery("select admin from Admin admin where admin.productCategory='sports' or admin.productCategory='books' or admin.productCategory='more' ",Admin.class);
			System.out.println("jdhygfi");
			return query.getResultList();
			}catch(Exception e){
				throw new ProductException(e.getMessage());
			}
	}

	@Override
	public Admin getProduct(String product) throws ProductException {
		try{
			TypedQuery<Admin> query=entityManager.createQuery("select admin from Admin admin where admin.productName='"+product+"'",Admin.class);
			return query.getSingleResult();
			}catch(Exception e){
				throw new ProductException(e.getMessage());
			}
	}

	@Override
	public List<Admin> getProductsAsc(String name,boolean asc) throws ProductException {
	
		/*try{
			TypedQuery<Admin> query=entityManager.createQuery("select admin from Admin admin where admin.productCategory='"+name+"' order by admin.productPrice ASC",Admin.class);
			return query.getResultList();
			}catch(Exception e){
				throw new ProductException(e.getMessage());
			}*/
		try
		{
			TypedQuery<Admin> list;
		if(asc)
		{
			list = entityManager.createQuery("select admin from Admin admin where admin.productCategory='"+name+"' order by admin.productPrice",Admin.class);	
		}
		else
		{
			
			list = entityManager.createQuery("select admin from Admin admin where admin.productCategory='"+name+"' order by admin.productPrice DESC",Admin.class);	
					
		}
		
		return list.getResultList();		
		}catch(Exception e){
			throw new ProductException(e.getMessage());
		}
			
	}

	@Override
	public List<Admin> getProductDesc(String category) throws ProductException {
          
		try{
			TypedQuery<Admin> query=entityManager.createQuery("select admin from Admin admin where admin.productCategory='"+category+"' order by admin.productPrice DESC",Admin.class);
			return query.getResultList();
			}catch(Exception e){
				throw new ProductException(e.getMessage());
			}
	}

	@Override
	public Admin getProductDetails(int id) throws ProductException {
		try{
			/*TypedQuery<Admin> query=entityManager.createQuery("select admin.productQuantity from Admin admin where admin.productId='"+id+"' ",Admin.class);
			System.out.println("hi");
			query.getSingleResult();*/
			Admin a=entityManager.find(Admin.class, id);
			System.out.println(a.getNumberOfProductExchanged()+"           "+a.getProductQuantity());
			return a;
			}catch(Exception e){
				throw new ProductException(e.getMessage());
			}
	}

	@Override
	public MerchantProduct getInvoice(int productid, int orderid)
			throws ProductException {
		MerchantProduct a=entityManager.find(MerchantProduct.class,productid);
		//entityManager.find(MerchantProduct.class, productid);
		return a;
	}
	
}
