package com.capgemini.flp.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.flp.dto.MerchantProduct;
import com.capgemini.flp.dto.Cart;
import com.capgemini.flp.dto.MerchantProduct;
import com.capgemini.flp.exception.ProductException;


@Repository
public class ProductDaoImpl implements IProductDao {

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public List<MerchantProduct> getProducts() throws ProductException {
		try{
			TypedQuery<MerchantProduct> query=entityManager.createQuery("from MerchantProduct",MerchantProduct.class);
			return query.getResultList();
			}catch(Exception e){
				throw new ProductException(e.getMessage());
			}
	}

	@Override
	public List<MerchantProduct> getElectronicProducts() throws ProductException {
		try{
			TypedQuery<MerchantProduct> query=entityManager.createQuery("select admin from MerchantProduct admin where admin.productCategory='Electronics'",MerchantProduct.class);
			return query.getResultList();
			}catch(Exception e){
				throw new ProductException(e.getMessage());
			}
	}

	@Override
	public List<MerchantProduct> getFashionProducts() throws ProductException {
		try{
			TypedQuery<MerchantProduct> query=entityManager.createQuery("select admin from MerchantProduct admin where admin.productCategory='Fashion' or admin.productCategory='fashion' ",MerchantProduct.class);
			return query.getResultList();
			}catch(Exception e){
				throw new ProductException(e.getMessage());
			}
	}

	@Override
	public List<MerchantProduct> getFurnitureProducts() throws ProductException {
		try{
			TypedQuery<MerchantProduct> query=entityManager.createQuery("select admin from MerchantProduct admin where admin.productCategory='Furniture' or admin.productCategory='furniture' ",MerchantProduct.class);
			return query.getResultList();
			}catch(Exception e){
				throw new ProductException(e.getMessage());
			}
	}

	@Override
	public List<MerchantProduct> getSportsBooksAndMoreProducts() throws ProductException {
		try{
			TypedQuery<MerchantProduct> query=entityManager.createQuery("select admin from MerchantProduct admin where admin.productCategory='sportsbooksandmore' ",MerchantProduct.class);
			System.out.println("jdhygfi");
			return query.getResultList();
			}catch(Exception e){
				throw new ProductException(e.getMessage());
			}
	}

	@Override
	public MerchantProduct getProduct(String product) throws ProductException {
		try{
			TypedQuery<MerchantProduct> query=entityManager.createQuery("select admin from MerchantProduct admin where admin.productName='"+product+"'",MerchantProduct.class);
			System.out.println(query);
			return query.getSingleResult();
			}catch(Exception e){
				throw new ProductException(e.getMessage());
			}
	}
	@Override
	public Cart addItemsToCart(Integer productId, String emailId) {
		Cart c=new Cart();
		
		// TODO Auto-generated method stub
		MerchantProduct product=entityManager.find(MerchantProduct.class,productId);
		c.setProductId(product.getProductId());
		c.setProductName(product.getProductName());
		c.setCustomeremailId(emailId);
		c.setProductCategory(product.getProductCategory());
		c.setProductPrice(product.getProductPrice());
		c.setProductDescription(product.getProductDescription());
		c.setProductQuantity(product.getProductQuantity());
		System.out.println(c.getCartId());
		
		entityManager.merge(c);
		return c;
	}
	@Override
	public void removeItemFromTheCart(Integer cartId) throws ProductException {
		// TODO Auto-generated method stub
		Cart cart=entityManager.find(Cart.class,cartId);
		entityManager.remove(cart);
		
	}


	@Override
	public List<MerchantProduct> getProductsAsc(String name,int asc) throws ProductException {
	
		try
		{
			TypedQuery<MerchantProduct> list;
		if(asc==1)
		{
			list = entityManager.createQuery("select admin from MerchantProduct admin where admin.productCategory='"+name+"' order by admin.productPrice",MerchantProduct.class);	
		}
		else if(asc==2)
		{
			
			list = entityManager.createQuery("select admin from MerchantProduct admin where admin.productCategory='"+name+"' order by admin.productPrice DESC",MerchantProduct.class);	
					
		}
		else
		{
			list = entityManager.createQuery("select admin from MerchantProduct admin where admin.productCategory='"+name+"' order by admin.numberOfProductSold DESC",MerchantProduct.class);
		}
		
		return list.getResultList();		
		}catch(Exception e){
			throw new ProductException(e.getMessage());
		}
			
	}

	@Override
	public List<MerchantProduct> getProductDesc(String category) throws ProductException {
          
		try{
			TypedQuery<MerchantProduct> query=entityManager.createQuery("select admin from MerchantProduct admin where admin.productCategory='"+category+"' order by admin.productPrice DESC",MerchantProduct.class);
			return query.getResultList();
			}catch(Exception e){
				throw new ProductException(e.getMessage());
			}
	}

	@Override
	public MerchantProduct getProductDetails(int id) throws ProductException {
		try{
			return entityManager.find(MerchantProduct.class, id);
			}catch(Exception e){
				throw new ProductException(e.getMessage());
			}
	}

	@Override
	public MerchantProduct getInvoice(int productid, int orderid)
			throws ProductException {
		MerchantProduct a=entityManager.find(MerchantProduct.class,productid);
		//entityManager.find(MerchantProduct.class, productid);
		return a;
	}

	@Override
	public List<MerchantProduct> getBestSelling(String category) throws ProductException {
		try{
			TypedQuery<MerchantProduct> query=entityManager.createQuery("select admin from MerchantProduct admin where admin.productCategory='"+category+"' order by admin.numberOfProductSold DESC",MerchantProduct.class);
			return query.getResultList();
			}catch(Exception e){
				throw new ProductException(e.getMessage());
			}
	}

	@Override
	public List<MerchantProduct> getSimilarProductsByCategory(String productCategory)
			throws ProductException {
		try {
			 TypedQuery <MerchantProduct> query=entityManager.createQuery("select admin from MerchantProduct admin where admin.productCategory = '"+productCategory+"'  order by admin.numberOfProductSold DESC",MerchantProduct.class);
				return query.getResultList(); 
			   } catch(PersistenceException e)
	            {
		           throw new ProductException(e.getMessage());
	            } 
		        
	
	}
	
	

	
	//Similar Products of same Name
	@Override
	public List<MerchantProduct> getSimilarProductsByName(String productName) throws ProductException 
	 {
		try 
		{
			TypedQuery <MerchantProduct> query=entityManager.createQuery("select admin from MerchantProduct admin where admin.productName = '"+productName+"' order by admin.numberOfProductSold DESC" ,MerchantProduct.class);
			return query.getResultList(); 
			 } catch(PersistenceException e)
	            {
		           throw new ProductException(e.getMessage());
	            } 
		        
	 }
	@Override
	public List<Cart> cartDetails(String emailId) {
		// TODO Auto-generated method stub
		TypedQuery<Cart> query=entityManager.createQuery("select cart from Cart cart where cart.customeremailId=?",Cart.class);
		query.setParameter(1, emailId);
		
		System.out.println(query.getResultList());
	
		return query.getResultList();
		
		
	}
		
}
